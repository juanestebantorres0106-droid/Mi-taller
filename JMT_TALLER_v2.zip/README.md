# JMT TALLER

Aplicación web adaptable (PWA) para administrar clientes y reparaciones, preparada para empaquetarse en Android mediante Capacitor.

## Incluye
- Registro y edición de clientes: nombre, apellido, teléfono y correo.
- Búsqueda de clientes por nombre, correo o teléfono; orden por fecha de registro.
- Múltiples reparaciones por cliente.
- Marca, descripción de falla, valor en COP, fechas de inicio, fin estimado y límite para reclamar.
- Estado de reparación e historial por cliente.
- Exportación y restauración de copias de seguridad en archivo JSON, incluidas las fotos guardadas.
- Captura/selección de foto de equipo, con reducción de tamaño.
- Interfaz adaptable a celulares y escritorio.

## Importante sobre los datos
Esta primera versión guarda datos en el almacenamiento local del navegador/dispositivo. No sincroniza automáticamente entre celulares ni crea copias en la nube. Usa el botón “Respaldo” para descargar una copia JSON y guardarla en otro lugar. La restauración reemplaza los datos locales actuales; confirma que descargaste una copia reciente antes de importar. Para uso empresarial multiusuario se recomienda añadir backend, autenticación y copias de seguridad.

## Ejecutar como web
Necesitas Node.js LTS instalado:
```bash
npm install
npm run start
```
Abre la dirección local que indique Vite.

## Preparar Android APK
Requisitos: Node.js LTS, Android Studio, Android SDK y JDK compatibles con la versión de Android Gradle Plugin instalada por Capacitor.
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
En Android Studio espera la sincronización de Gradle. Para generar APK de prueba: **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Android Studio mostrará la ruta del APK generado. Para distribución pública, genera un APK firmado o un AAB desde **Build > Generate Signed Bundle / APK**.

## Identificador del paquete
`com.jmttaller.app`

## Sugerencias antes de producción
- Probar permisos de cámara en el dispositivo real.
- Implementar exportación/importación de respaldo.
- Considerar base de datos segura y sincronización si se usará en varios dispositivos.
- Definir política de tratamiento de datos personales acorde con la normativa aplicable.


## Generar el APK desde un celular (compilación en la nube)
Este ZIP incluye `.github/workflows/build-apk.yml` para compilar con GitHub Actions. Sube los archivos del proyecto a un repositorio de GitHub (incluida la carpeta oculta `.github/workflows`), abre la pestaña **Actions**, elige **Generar APK JMT TALLER** y pulsa **Run workflow**. Al terminar, abre la ejecución y descarga el artefacto **JMT-TALLER-APK**. Dentro encontrarás `app-debug.apk`.
La primera compilación puede tardar varios minutos. El APK es de prueba y no está firmado para publicación en Play Store. Los datos se guardan localmente en el dispositivo; no hay sincronización en la nube.
